import { StatusBar } from 'expo-status-bar';
import { Pressable, Text, View } from 'react-native';
import { TextInput } from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './style';
import { useState } from 'react';

export default function Cadastro() {
  const navigation = useNavigation();
  const [nome, setNome] = useState();
  const [telefone, setTelefone] = useState();
  const [email, setEmail] = useState();
  const [senha, setSenha] = useState();

  const salvarDados = async () => {
    try {
      await AsyncStorage.setItem('nome', nome);
      await AsyncStorage.setItem('telefone', telefone);
      await AsyncStorage.setItem('email', email);
      await AsyncStorage.setItem('senha', senha);
      alert('Dados salvos com sucesso!');
      navigation.navigate('Login');
    } catch (error) {
      console.error('Erro ao salvar os dados:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.textInput}>Nome</Text>
      <View style={styles.inputArea}>
        <TextInput 
        value={nome} 
        style={styles.input} 
        onChangeText={(text) => setNome(text)} 
        />
      </View>

      <Text style={styles.textInput}>Telefone</Text>
      <View style={styles.inputArea}>
        <TextInput 
        value={telefone} 
        style={styles.input} 
        onChangeText={(text) => setTelefone(text)} 
        />
      </View>

      <Text style={styles.textInput}>E-mail</Text>
      <View style={styles.inputArea}>
        <TextInput 
        value={email} 
        style={styles.input} 
        onChangeText={(text) => setEmail(text)} 
        />
      </View>

      <Text style={styles.textInput}>Senha</Text>
      <View style={styles.inputArea}>
        <TextInput 
        value={senha} 
        style={styles.input} 
        onChangeText={(text) => setSenha(text)} 
        />
      </View>

      <View style={styles.buttonArea}>
        <Pressable style={styles.button} onPress={salvarDados}>
          <Text style={styles.buttontext}>Cadastrar</Text>
        </Pressable>
      </View>
      <StatusBar style="auto" />
    </View>
  );
}