import { StyleSheet } from "react-native";
export default StyleSheet.create({
  container: { //Corpo
    flex: 1,
    backgroundColor: '#e8f0fe',
    alignItems: 'center',
    justifyContent: 'center',
  },
  felinosArea:{ //Container
    flex:1,
    flexDirection:'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height:'100%',
    width:'80%',
    marginBottom: 30,
  },
  buttonArea:{ //Area
    height:'100%',
    width:'50%',
  },
  text:{
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center', 
    color: 'black',
  },
  felinos:{ //Pressable
    width:'100%',
    height:'100%',
  },
  modal: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e8f0fe',
  },
  //MODAL
  title: { // Título
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: "25%",
    color: '#BF7E04',
  },
  secondTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 30,
    color: 'black',
  },
  description: {
    fontSize: 14,
    color: 'black',
    fontWeight: 500,
    marginBottom: 15,
    textAlign: 'left',
    width: '80%'
  },
  subTitles: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#BF7E04',
  },
  imagemContainer: {
    width: '80%',
    height: '20%',
    marginBottom: 15,
  },
  image: {
    width: '100%',
    height: '100%',
    marginTop: "25%",
  },
});