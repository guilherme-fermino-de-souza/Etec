import { StatusBar } from 'expo-status-bar';
import { Text, View } from 'react-native';
import { TextInput, TouchableOpacity } from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './style';
import { useState } from 'react';

export default function Login() {
  const navigation = useNavigation();
  const [email, setEmail] = useState();
  const [senha, setSenha] = useState();

  const verificacao = async () => {
    try {
      const emailVerificacao = await AsyncStorage.getItem('email');
      const senhaVerificacao = await AsyncStorage.getItem('senha');
      
      if (emailVerificacao === email && senhaVerificacao === senha) {
        navigation.navigate('Territorios');
      } else {
        alert('Senha ou Email Incorretos!');
      }
    } catch (error) {
      console.error('Erro ao verificar dados:', error);
      alert('Ocorreu um erro ao realizar o login.');
    }
  }
  return (
    <View style={styles.container}>
        <Text style={styles.textInput}>Email</Text>
        <View style={styles.inputArea}>
          <TextInput
          style={styles.input}
          value={email}
          onChangeText={(text) => setEmail(text)}
          />
        </View>

        <Text style={styles.textInput}>Senha</Text>
        <View style={styles.inputArea}>
        <TextInput
        style={styles.input}
        value={senha}
        onChangeText={(text) => setSenha(text)}
        />
        </View>

      <View style={styles.buttonArea}>

        <TouchableOpacity style={styles.button}
        onPress={ () => navigation.navigate('Cadastro')}>
          <Text style={styles.buttontext}>Não Tenho Conta</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button}
        onPress={verificacao}> 
          <Text style={styles.buttontext}>Entrar</Text>
        </TouchableOpacity>

      </View>
      <StatusBar style="auto" />
    </View>
  );
}
