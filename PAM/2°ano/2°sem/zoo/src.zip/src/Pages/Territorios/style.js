import { StyleSheet } from "react-native";

export default StyleSheet.create({
  container: { //Corpo
    flex: 1,
    backgroundColor: '#e8f0fe',
    alignItems: 'center',
    justifyContent: 'center',
  },
  territorioArea:{ //Container
    flex:1,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection:'row',
    height:'100%',
    width:'80%',
    marginBottom: 30,
  },
  buttonArea:{ //Area
    height:'85%',
    width:'45%',
  },
  text:{
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center', 
    color: 'black',
  },
  territorio:{ //Pressable
    width:'100%',
    height:'100%',
  },
  header:{
    flex:0.5
  }

});