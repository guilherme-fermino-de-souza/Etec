import { StatusBar } from 'expo-status-bar';
import { Text, View, Image } from 'react-native';
import { Pressable} from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style.js'

export default function Territorios() {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.territorioArea}>
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={500}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('Felinos')}>
              <Image style={{width:'100%',height:'70%'}}
              source={require('../../../img/lion.png')} />
              <Text style={styles.text}>Felídeos</Text>
            </Pressable>
        </Animatable.View>
        
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={600}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('Canideos')}>
              <Image style={{width:'100%',height:'70%'}}
              source={require('../../../img/dog.png')} />
              <Text style={styles.text}>Canídeos</Text>
            </Pressable>
        </Animatable.View>
      </View>

      <View style={styles.territorioArea}>
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={1000}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('Ursidae')}>
              <Image style={{width:'100%',height:'70%'}}
              source={require('../../../img/bear.png')} />
              <Text style={styles.text}>Ursídeos</Text>
            </Pressable>
        </Animatable.View>
        
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={1100}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('Hienideos')}>
              <Image style={{width:'100%',height:'70%'}}
              source={require('../../../img/lobo.png')} />
              <Text style={styles.text}>Hienídeos</Text>
            </Pressable>
        </Animatable.View>
      </View>

      <View style={styles.territorioArea}>
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={1500}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('Baleias')}>
              <Image style={{width:'100%',height:'70%', backgroundColor:'blue', borderRadius: 100}}
              source={require('../../../img/whale.png')} />
              <Text style={styles.text}>Misticetos</Text>
            </Pressable>
        </Animatable.View>

        
        <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={1000} delay={1600}>
            <Pressable style={styles.territorio} onPress={ () => navigation.navigate('AvesdeRapina')}>
              <Image style={{width:'100%',height:'70%'}}
              source={require('../../../img/bird.png')} />
              <Text style={styles.text}>Falconídeos</Text>
             </Pressable>
        </Animatable.View>
      </View>
      <StatusBar style="auto" />
    </View>
  );
}