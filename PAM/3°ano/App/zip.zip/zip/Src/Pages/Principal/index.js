import { StatusBar } from 'expo-status-bar';
import { Text, View, Image } from 'react-native';
import { Pressable, SafeAreaView} from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style.js'

export default function Principal() {
    const navigation = useNavigation();
    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.containerBotoes}>
                <Animatable.View style={styles.areaBotao} animation="fadeIn" duration={1000} delay={0}> 
                    <Pressable style={styles.botao} onPress={ () => navigation.navigate('Remedio')}>
                        <Image style={{width: '100%', height: '100%'}} 
                            source={require('../../../Imagens/section-remedios/remedio.png')}
                        />
                    </Pressable>
                </Animatable.View> 
                <Animatable.View style={styles.areaBotao} animation="fadeIn" duration={1000} delay={500}>
                    <Pressable style={styles.botao} onPress={ () => navigation.navigate('Agua')}>
                        <Image style={{width: '100%', height: '100%'}} 
                            source={require('../../../Imagens/section_frutas/fruits.png')}
                        />
                    </Pressable>
                </Animatable.View>  
                <Animatable.View style={styles.areaBotao} animation="fadeIn" duration={1000} delay={1000}>
                    <Pressable style={styles.botao} onPress={ () => navigation.navigate('Imc')}>
                        <Image style={{width: '100%', height: '100%'}} 
                            source={require('../../../Imagens/section_imc/imc.png')}
                        />
                    </Pressable>
                </Animatable.View>
                <Animatable.View style={styles.areaBotao} animation="fadeIn" duration={1000} delay={1500}> 
                    <Pressable style={styles.botao} onPress={ () => navigation.navigate('Remedio')}>
                        <Image style={{width: '100%', height: '100%'}} 
                            source={require('../../../Imagens/section_dormir/dormir.png')}
                        />
                    </Pressable>
                </Animatable.View>
                <Animatable.View style={styles.areaBotao} animation="fadeIn" duration={1000} delay={2000}> 
                    <Pressable style={styles.botao} onPress={ () => navigation.navigate('Imc')}>
                        <Image style={{width: '100%', height: '100%'}} 
                            source={require('../../../Imagens/section_agua/gotas.png')}
                        />
                    </Pressable>
                </Animatable.View>
            </View>
        </SafeAreaView>
    );
}