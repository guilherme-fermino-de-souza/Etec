import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: { //Corpo
        flex: 1,
        backgroundColor: '#e8f0fe',
        alignItems: 'center',
    },
    containerBotoes: { //Botões topo
        display: 'flex',
        flexDirection: "row",
        width: '80%',
        margin: 'auto',
        marginVertical: 35,
    },
    areaBotao: {
        height: 60,
        width: 60,
        marginHorizontal: 5,
    },
    botao: { //Img
        height: '100%',
        width: '100%',
    }
});