import { StatusBar } from 'expo-status-bar';
import { Text, View, Image } from 'react-native';
import { Pressable} from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style.js'

export default function Agua() {
    const { navigation } = useNavigation();
    return (
        <View style={styles.container}>
            <Text>Água</Text>
        </View>
    )
}