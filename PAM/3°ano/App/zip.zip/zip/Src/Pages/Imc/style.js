import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-start',
        width: '90%',
        margin: 'auto',
    },
    logo: {
        marginTop: 10,
        margin: 'auto',
    },
    logoTexto: {
        marginTop: 10,
        margin: 'auto',
    },
    paragrafo: {
        marginTop: 20,   
    },
    campo: {
        height: 30,
        borderColor: 'black',
        borderWidth: 3,
        borderRadius: 25,
        marginTop: 20,
        paddingLeft: 5,
    },
    botao: {
        display: 'flex',
        alignItems: 'flex-end',
        marginVertical: 40,
    },
    botaoEstilo: {
        backgroundColor: '#02733E',
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold',
        borderRadius: 25,
    },
    resultado: {
        height: 30,
        borderColor: 'black',
        borderWidth: 3,
        borderRadius: 25 ,
        paddingLeft: 5,
    },
});