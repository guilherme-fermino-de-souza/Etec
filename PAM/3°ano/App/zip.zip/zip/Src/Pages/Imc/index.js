import { StatusBar } from 'expo-status-bar';
import { Text, View, Image} from 'react-native';
import { useState } from "react";
import { Button, Pressable, SafeAreaView, TextInput} from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style.js'

export default function Imc() {
    const [altura, setAltura] = useState();
    const [peso, setPeso] = useState();
    const [resultado, setResultado] = useState();
    const [indiceSelecionado, setIndiceSelecionado] = useState(0);
    const [imc, setImc] = useState([
        {
            imc: 'Imc',
            titulo: 'Tipo',
            texto: 'Descrição.',
        },
        {
            imc: '18,5 ou menos',
            titulo: 'Abaixo do normal',
            texto: 'Procure um médico. Algumas pessoas têm um baixo peso por características do seu organismo e tudo bem. Outras podem estar enfrentando problemas, como a desnutrição. É preciso saber qual é o caso.',
        },
        {
            imc: 'Entre 18,6 e 24,9',
            titulo: 'Normal',
            texto: 'Que bom que você está com o peso normal! E o melhor jeito de continuar assim é mantendo um estilo de vida ativo e uma alimentação equilibrada.',
        },
        {
            imc: 'Entre 25,0 e 29,9',
            titulo: 'Sobrepeso',
            texto: 'Ele é, na verdade, uma pré-obesidade e muitas pessoas nessa faixa já apresentam doenças associadas, como diabetes e hipertensão. Importante rever hábitos e buscar ajuda antes de, por uma série de fatores, entrar na faixa da obesidade pra valer.',
        },
        {
            imc: 'Entre 30,0 e 34,9',
            titulo: 'Obesidade grau I',
            texto: 'Sinal de alerta! Chegou na hora de se cuidar, mesmo que seus exames sejam normais. Vamos dar início a mudanças hoje! Cuide de sua alimentação. Você precisa iniciar um acompanhamento com nutricionista e/ou endocrinologista.',
        },
        {
            imc: 'Entre 35,0 e 39,9',
            titulo: 'Obesidade grau II',
            texto: 'Mesmo que seus exames aparentem estar normais, é hora de se cuidar, iniciando mudanças no estilo de vida com o acompanhamento próximo de profissionais de saúde.',
        },
        {
            imc: 'Acima de 40,0',
            titulo: 'Obesidade grau III',
            texto: 'Aqui o sinal é vermelho, com forte probabilidade de já existirem doenças muito graves associadas. O tratamento deve ser ainda mais urgente.',
        },
    ]);

    const CalcularImc = () => {
        if (altura >= 0 && peso >= 0) {
            setResultado(peso / (altura*altura));
            if (resultado <= 18.5) {
                setIndiceSelecionado(1);
            } else if (resultado <= 24.9) {
                setIndiceSelecionado(2);
            } else if (resultado <= 29.9) {
                setIndiceSelecionado(3);
            } else if (resultado <= 34.9) {
                setIndiceSelecionado(4);
            } else if (resultado <= 39.9) {
                setIndiceSelecionado(5);
            } else {
                setIndiceSelecionado(6);
            }
        }
    }

    return (
        <SafeAreaView style={styles.container}>

            <View style={styles.logo}>
                <Image style={{width: 107, height: 107}}
                    source={require('../../../Imagens/section_imc/imc.png')}
                />
            </View>

            <View style={styles.logoTexto}>
                <Text styles={{fontSize: 25, fontWeight: 'bold'}}>Calcular IMC</Text>
            </View>
            

            <View style={styles.paragrafo}>
                <Text style={{fontSize: 16, fontWeight: 'bold'}}>    O IMC é um padrão internacional para avaliar o grau de sobrepeso e obesidade. 
                    A Organização Mundial da Saúde (OMS) utiliza o IMC para calcular o peso ideal de 
                    cada pessoa.
                 </Text>
            </View>

            <View style={styles.calculadora}>
                <TextInput style={styles.campo}
                    value={altura}
                    placeholder="Altura em metros"
                    onChangeText={(value) => setAltura(value)}
                />
                <TextInput style={styles.campo}
                    value={peso}
                    placeholder="Peso em quilos"
                    onChangeText={(value) => setPeso(value)}
                />
            </View>

            <View style={styles.botao}>
                <Button
                    styles={styles.botaoEstilo}
                    color='#02733E'
                    title="Calcular Imc"
                    onPress={() => CalcularImc()}
                />
            </View>

            <View style={styles.resultado}>
                <Text style={styles.resultImc}>{imc[indiceSelecionado].imc}</Text>
                <Text style={styles.resultTitle}>{imc[indiceSelecionado].titulo}</Text>
                <Text style={styles.resultText}>{imc[indiceSelecionado].texto}</Text>
            </View>
        </SafeAreaView>
    )
}