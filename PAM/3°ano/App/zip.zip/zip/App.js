import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

/* Como o componente App.js é sempre renderizado
primeiro, devemos criar rotas nele para os outros 
componetes */

//Cores: red:#F22816, blue:#0476D9, lightblue:#049DD9, yellow:#F2E205

import Home from './Src/Pages/Home';
import Login from './Src/Pages/Login';
import Cadastro from './Src/Pages/Cadastro';
import Principal from './Src/Pages/Principal';
import Imc from './Src/Pages/Imc';
import Agua from './Src/Pages/Agua';
import Remedios from './Src/Pages/Remedios';

const Stack = createNativeStackNavigator ();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>

      <Stack.Screen name="Home" component={Home}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>        
      <Stack.Screen name="Login" component={Login}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      <Stack.Screen name="Cadastro" component={Cadastro}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      <Stack.Screen name="Principal" component={Principal}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      <Stack.Screen name="Imc" component={Imc}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      <Stack.Screen name="Agua" component={Agua}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      <Stack.Screen name="Remedios" component={Remedios}
          options={{headerStyle:{backgroundColor:'#02733E'},headerTintColor:'white',headerTitleAlign:'center'}}/>
      </Stack.Navigator>

    </NavigationContainer>
  );
}
